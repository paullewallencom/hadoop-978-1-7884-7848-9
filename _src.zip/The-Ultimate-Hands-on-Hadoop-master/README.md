## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/the-ultimate-hands-on-hadoop-video/9781788478489)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# The-Ultimate-Hands-on-Hadoop
Code Repository for The Ultimate Hands-on Hadoop, Published by Packt
